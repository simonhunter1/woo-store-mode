<?php

/**
 * Fired during plugin activation
 *
 * @link       http://remedyone.com
 * @since      1.0.0
 *
 * @package    Rm_Woo_Store_Mode
 * @subpackage Rm_Woo_Store_Mode/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Rm_Woo_Store_Mode
 * @subpackage Rm_Woo_Store_Mode/includes
 * @author     Simon Hunter <simon@remedyone.come>
 */
class Rm_Woo_Store_Mode_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}


}
